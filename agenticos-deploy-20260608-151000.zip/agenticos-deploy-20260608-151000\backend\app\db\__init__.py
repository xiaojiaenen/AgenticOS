"""Database helpers for AgenticOS."""

