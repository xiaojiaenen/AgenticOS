﻿"""Website 生成工具 — copy_template / build / deploy"""

import shutil
from pathlib import Path

from wuwei.tools import ToolRegistry

from app.core.data_path import (
    WEBSITES_DIR,
    WEBSITE_TEMPLATES_DIR,
    get_current_session_id,
    get_current_user_id,
    next_version_dir, _parse_dir_name,
    set_current_website_dir,
)

ALLOWED_STACKS = {"vanilla", "vue", "react"}


def register_website_tools(registry: ToolRegistry) -> None:

    @registry.tool(display_name="复制网站模板")
    async def copy_template(stack: str) -> str:
        """复制基础模板到目标目录，作为新项目的起点。

        目录名自动生成，格式为 u<用户ID>_s<会话ID>_v<版本号>，无需手动指定。

        参数:
          stack: 技术栈，可选 "vanilla"、"vue"、"react"

        返回:
          操作结果描述，包含生成的目录名
        """
        if stack not in ALLOWED_STACKS:
            return f"不支持的技术栈：{stack}。可选：{', '.join(sorted(ALLOWED_STACKS))}"

        source_dir = WEBSITE_TEMPLATES_DIR / stack
        if not source_dir.exists():
            return f"模板目录不存在：{source_dir}"

        user_id = get_current_user_id()
        session_id = get_current_session_id()
        if not session_id:
            return "错误：无法获取当前会话 ID，请刷新页面重试"

        target_dir = next_version_dir(WEBSITES_DIR, user_id, session_id)
        # Should never collide since we always +1, but guard anyway
        if target_dir.exists():
            return (
                f"目标目录已存在：{target_dir}\n"
                f"如果要修改已有项目，请直接使用文件工具编辑 {target_dir} 下的文件，"
                f"或调用 check_website_project 查看所有项目。"
            )

        try:
            shutil.copytree(source_dir, target_dir)
        except OSError as e:
            return f"复制失败：{e}"

        files = sorted(
            str(p.relative_to(target_dir)).replace("\\", "/")
            for p in target_dir.rglob("*") if p.is_file()
        )
        file_list = "\n".join(f"  {f}" for f in files)

        # Set current website dir so file tools resolve relative paths here
        set_current_website_dir(str(target_dir))

        return (
            f"已复制 {stack} 模板到 {target_dir}\n"
            f"项目目录名：{target_dir.name}\n"
            f"\n项目文件：\n{file_list}\n"
            f"\n项目目录已设置，后续文件操作会自动定位到此目录。"
            f"\n下一步：使用文件工具编辑项目文件（只需提供相对路径如 css/style.css），然后调用 build_website('{target_dir.name}') 构建。"
        )
    @registry.tool(display_name="检查当前项目")
    async def check_website_project() -> str:
        """检查当前会话的网站项目是否存在。

        根据 user_id 和 session_id 查找匹配的项目目录。
        如果找到，自动设置为当前项目目录并返回信息。
        如果未找到，返回提示需要先调用 copy_template。

        返回:
          项目状态信息，包含目录名和文件数
        """
        user_id = get_current_user_id()
        session_id = get_current_session_id()
        if not session_id:
            return "错误：无法获取当前会话 ID"

        if not WEBSITES_DIR.exists():
            return "当前会话暂无项目，请调用 copy_template(stack) 创建"

        # 查找匹配 user_id + session_id 的最新版本
        candidates = []
        for d in WEBSITES_DIR.iterdir():
            if not d.is_dir():
                continue
            parsed = _parse_dir_name(d.name)
            if parsed and parsed[0] == user_id and parsed[1] == session_id:
                candidates.append((d, parsed[2]))

        if not candidates:
            return "当前会话暂无项目，请调用 copy_template(stack) 创建"

        # 取最新版本
        candidates.sort(key=lambda x: x[1], reverse=True)
        project_dir, version = candidates[0]
        file_count = len([f for f in project_dir.rglob("*") if f.is_file()])

        # 自动设置为当前项目目录
        set_current_website_dir(str(project_dir))

        has_dist = (project_dir / "dist").exists()
        status = "已构建" if has_dist else "未构建"

        return (
            f"项目已存在：{project_dir.name}\n"
            f"版本：v{version}，文件数：{file_count}，状态：{status}\n"
            f"项目目录已设置，可直接使用文件工具编辑（只需提供相对路径）。"
        )

    @registry.tool(display_name="构建网站")
    async def build_website(project_slug: str) -> str:
        """对指定项目执行 npm install && npm run build（沙箱隔离）。

        参数:
          project_slug: 项目目录名（data/websites/ 下的目录名，如 u1_abc123_v1）

        返回:
          构建结果
        """
        from app.services.sandbox import Sandbox

        target_dir = WEBSITES_DIR / project_slug
        if not target_dir.exists():
            return f"项目目录不存在：{target_dir}"

        pkg_json = target_dir / "package.json"
        if not pkg_json.exists():
            return f"项目缺少 package.json：{pkg_json}"

        sandbox = Sandbox(workspace=target_dir, timeout=120, max_output=12000)

        # npm install（使用 --ignore-scripts 防止恶意包脚本）
        install_result = await sandbox.execute("npm install --ignore-scripts", timeout=120)
        if not install_result.success:
            return (
                f"npm install 失败（退出码 {install_result.exit_code}）：\n"
                f"{install_result.stderr[-3000:]}"
            )

        # npm run build
        build_result = await sandbox.execute("npm run build", timeout=120)

        if not build_result.success:
            return (
                f"npm run build 失败（退出码 {build_result.exit_code}）：\n"
                f"{build_result.stderr[-3000:]}"
            )

        dist_dir = target_dir / "dist"
        dist_files = []
        if dist_dir.exists():
            dist_files = sorted(
                str(p.relative_to(dist_dir)).replace("\\", "/")
                for p in dist_dir.rglob("*") if p.is_file()
            )

        return (
            f"构建成功！\n"
            f"项目目录：{target_dir}\n"
            f"产物目录：{dist_dir}\n"
            f"产物文件（{len(dist_files)} 个）：\n" +
            "\n".join(f"  {f}" for f in dist_files[:30]) +
            ("\n  ..." if len(dist_files) > 30 else "")
        )

    @registry.tool(display_name="部署网站（需管理员审批）")
    async def deploy_website(project_slug: str) -> str:
        """请求部署网站到 nginx 服务器。需要管理员审批后才能上线。

        部署流程：
        1. 检查项目是否已构建（dist/ 目录存在）
        2. 创建部署请求（状态：pending）
        3. 管理员在后台审批
        4. 审批通过后自动复制 dist/ 到 nginx 服务目录
        5. 网站可通过 /sites/{slug}/ 访问

        参数:
          project_slug: 项目目录名（如 u1_abc123_v1）

        返回:
          部署请求状态
        """
        from app.services.website_deploy_service import WebsiteDeployService

        target_dir = WEBSITES_DIR / project_slug
        if not target_dir.exists():
            return f"项目目录不存在：{target_dir}"

        dist_dir = target_dir / "dist"
        if not dist_dir.exists():
            return (
                f"项目尚未构建（dist/ 目录不存在）。\n"
                f"请先调用 build_website('{project_slug}') 构建项目，"
                f"构建成功后再请求部署。"
            )

        # 检查 dist 内容
        dist_files = [f for f in dist_dir.rglob("*") if f.is_file()]
        if not dist_files:
            return "dist/ 目录为空，没有可部署的文件"

        # 获取用户信息
        user_id = get_current_user_id()
        session_id = get_current_session_id()

        # 从目录名解析 stack
        parsed = _parse_dir_name(project_slug)
        stack = "vanilla"  # default

        # 创建部署请求
        deploy_service = WebsiteDeployService()
        try:
            deploy = deploy_service.request_deploy(
                session_id=session_id or "",
                project_slug=project_slug,
                stack=stack,
                requested_by=user_id or 0,
            )
        except FileNotFoundError as e:
            return str(e)

        deploy_id = deploy.get("id", "?")

        return (
            f"部署请求已提交（ID: {deploy_id}）\n"
            f"\n📋 部署信息：\n"
            f"  项目：{project_slug}\n"
            f"  文件数：{len(dist_files)}\n"
            f"  状态：等待管理员审批\n"
            f"\n⏳ 管理员审批通过后，网站将自动部署到 /sites/{project_slug}/\n"
            f"你可以在后台「网站部署管理」中查看审批状态。"
        )
